#!/bin/sh

echo
echo "Sample Selenium-RC Test - clean"
echo "-------------------------------"

echo

rm -Rf build
ls build
