package jax;

import com.googlecode.webdriver.WebDriver;
import com.googlecode.webdriver.WebElement;
import com.googlecode.webdriver.By;
import com.googlecode.webdriver.NoSuchElementException;
import com.googlecode.webdriver.firefox.FirefoxDriver;
import org.junit.Before;
import org.junit.After;
import org.junit.matchers.TypeSafeMatcher;
import org.hamcrest.Matcher;
import org.hamcrest.Description;

public class AbstractWebDriverTest {

    protected WebDriver _driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.firefox.useExisting", "true");
        _driver = new FirefoxDriver();
    }

    @After
    public void tearDown() {
        _driver.close();
    }

    //// Syntactic sugar ////

    protected WebElement into(WebElement inputField) {
        return inputField;
    }

    protected WebDriver currentPage() {
        return _driver;
    }

    //// Actions ////

    protected void goTo(EntryPage entryPage) {
        _driver.get(entryPage.getUrl());
    }

    protected void enter(String value, WebElement inputField) {
        inputField.sendKeys(value);
    }

    protected void clickOn(WebElement webElement) {
        webElement.click();
    }

    //// Finders ////

    protected WebElement button(String label) {
        try {
            return _driver.findElement(By.xpath("//input[@type = 'submit' and @value = '" + label + "']"));
        } catch (NoSuchElementException e) {
            for (WebElement button : _driver.findElements(By.xpath("//button"))) {
                if (button.getText().equals(label)) {
                    return button;
                }
            }
            throw e;
        }
    }

    protected WebElement inputField(String name) {
        return _driver.findElement(By.name(name));
    }

    protected WebElement link(String linkText) {
        return _driver.findElement(By.linkText(linkText));
    }

    //// Matchers ////

    protected Matcher<WebDriver> containsText(final String expectedText) {
        return new TypeSafeMatcher<WebDriver>() {
            public boolean matchesSafely(WebDriver driver) {
                return driver.findElement(By.xpath("/html/body")).getText().contains(expectedText);
            }

            public void describeTo(Description description) {
                description.appendText("a page containing \"" + expectedText + "\"");
            }
        };
    }

}
