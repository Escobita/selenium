package jax;

public enum EntryPage {

    GOOGLE_HOMEPAGE("http://www.google.com/ncr"),
    GOOGLE_SUGGEST("http://www.google.com/webhp?complete=1&hl=en");

    private final String _url;

    EntryPage(String url) {
        _url = url;
    }

    public String getUrl() {
        return _url;
    }

}
