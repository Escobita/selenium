package jax;

import static jax.EntryPage.*;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

public class GoogleImageSearch extends AbstractWebDriverTest {

    @Test
    public void searchForMichaelTamm() {
        goTo(GOOGLE_HOMEPAGE);
        clickOn(link("Images"));
        assertThat(currentPage().getTitle(), is("Google Image Search"));
        enter("Michael Tamm", into(inputField("q")));
        clickOn(button("Search Images"));
        assertThat(currentPage(), containsText("Results 1 - 20"));
    }

}

