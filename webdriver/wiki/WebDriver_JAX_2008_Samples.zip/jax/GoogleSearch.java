package jax;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import com.googlecode.webdriver.WebDriver;
import com.googlecode.webdriver.By;
import com.googlecode.webdriver.WebElement;
import com.googlecode.webdriver.ie.InternetExplorerDriver;
import com.googlecode.webdriver.htmlunit.HtmlUnitDriver;
import com.googlecode.webdriver.firefox.FirefoxDriver;
import com.googlecode.webdriver.htmlunit.HtmlUnitDriver;
import com.googlecode.webdriver.ie.InternetExplorerDriver;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import static org.junit.matchers.JUnitMatchers.*;

public class GoogleSearch {

    private WebDriver _driver;

    @Before
    public void setUp() {
        _driver = new FirefoxDriver();
        // _driver = new HtmlUnitDriver();
        // _driver = new InternetExplorerDriver();
    }

    @After
    public void tearDown() {
        _driver.close();
    }

    @Test
    public void searchForJaxMichaelTamm() {
        _driver.get("http://www.google.com/ncr");
        _driver.findElement(By.name("q")).sendKeys("Jax Michael Tamm");
        _driver.findElement(By.xpath("//input[@type = 'submit' and @value = 'Google Search']")).click();
        WebElement body = _driver.findElement(By.xpath("/html/body"));
        assertThat(body.getText(), containsString("JAX 2008"));
    }

}
