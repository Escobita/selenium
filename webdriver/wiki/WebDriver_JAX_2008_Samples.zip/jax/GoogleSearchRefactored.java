package jax;

import static jax.EntryPage.*;
import org.junit.Test;
import static org.junit.Assert.*;

public class GoogleSearchRefactored extends AbstractWebDriverTest {

    @Test
    public void searchForJaxMichaelTamm() {
        goTo(GOOGLE_HOMEPAGE);
        enter("Jax Michael Tamm", into(inputField("q")));
        clickOn(button("Google Search"));
        assertThat(currentPage(), containsText("JAX 2008"));
    }

}
