package jax;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import com.googlecode.webdriver.WebDriver;
import com.googlecode.webdriver.By;
import com.googlecode.webdriver.WebElement;
import com.googlecode.webdriver.firefox.FirefoxDriver;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

public class GoogleSuggest {

    private WebDriver _driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.firefox.useExisting", "true");
        _driver = new FirefoxDriver();
    }

    @After
    public void tearDown() {
        _driver.close();
    }

    @Test
    public void googleSuggest() throws InterruptedException {
        _driver.get("http://www.google.com/webhp?complete=1&hl=en");
        _driver.findElement(By.name("q")).sendKeys("jav");
        // Give Google Suggest some time to load suggestions ...
        Thread.sleep(500);
        WebElement firstSuggestion = _driver.findElement(By.xpath("//table[@id = 'completeTable']//td"));
        assertThat(firstSuggestion.getText(), is("java"));
        firstSuggestion.click();
        assertThat(_driver.getTitle(), is("java - Google Search"));
        WebElement linkToJavaHomepage = _driver.findElement(By.linkText("java.com: Hot Games, Cool Apps"));
        linkToJavaHomepage.click();
        assertTrue(_driver.getCurrentUrl().startsWith("http://www.java.com/"));
    }

}
